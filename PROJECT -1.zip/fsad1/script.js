/**
 * EventVision Premium Ticketing Platform
 * Core JavaScript Logic — API-backed version
 */

const API_BASE = 'http://localhost:3000/api';

document.addEventListener('DOMContentLoaded', () => {
    // ==========================================
    // Core Application State
    // ==========================================
    const STORAGE_KEY_CURRENT_USER = 'eventvision_currentUser';
    let currentUser = JSON.parse(localStorage.getItem(STORAGE_KEY_CURRENT_USER)) || null;

    function saveCurrentUser() {
        localStorage.setItem(STORAGE_KEY_CURRENT_USER, JSON.stringify(currentUser));
    }

    // ==========================================
    // DOM Elements - Navigation & Views
    // ==========================================
    const navBrowse = document.getElementById('nav-browse');
    const navHistory = document.getElementById('nav-history');
    const navManage = document.getElementById('nav-manage');
    const viewAttendee = document.getElementById('attendee-view');
    const viewHistory = document.getElementById('history-view');
    const viewOrganizer = document.getElementById('organizer-view');

    // ==========================================
    // Navigation Logic
    // ==========================================
    function switchView(viewName) {
        if (!currentUser && (viewName === 'history' || viewName === 'organizer')) {
            openModal('modal-login');
            showToast('Authentication Required', 'Please log in to access this page.', 'warning');
            return;
        }

        // Update Nav
        document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
        if (viewName === 'attendee') {
            navBrowse.classList.add('active');
            viewOrganizer.classList.add('hidden');
            viewHistory.classList.add('hidden');
            viewAttendee.classList.remove('hidden');
            renderAttendeeEvents();
        } else if (viewName === 'organizer') {
            navManage.classList.add('active');
            viewAttendee.classList.add('hidden');
            viewHistory.classList.add('hidden');
            viewOrganizer.classList.remove('hidden');
            renderOrganizerDashboard();
        } else if (viewName === 'history') {
            navHistory.classList.add('active');
            viewAttendee.classList.add('hidden');
            viewOrganizer.classList.add('hidden');
            viewHistory.classList.remove('hidden');
            renderBookingHistory();
        }
    }

    navBrowse.addEventListener('click', (e) => { e.preventDefault(); switchView('attendee'); });
    navHistory.addEventListener('click', (e) => { e.preventDefault(); switchView('history'); });
    navManage.addEventListener('click', (e) => { e.preventDefault(); switchView('organizer'); });

    // ==========================================
    // Utils
    // ==========================================
    function formatDate(dateString) {
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        return new Date(dateString).toLocaleDateString('en-US', options);
    }

    function formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
    }

    // ==========================================
    // Toast Notification System
    // ==========================================
    const toastContainer = document.getElementById('toast-container');

    function showToast(title, message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icon = type === 'success' ? 'ph-check-circle' : 'ph-warning-circle';
        
        toast.innerHTML = `
            <i class="ph ${icon}"></i>
            <div class="toast-content">
                <h4>${title}</h4>
                <p>${message}</p>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        // Trigger reflow for transition
        toast.offsetHeight;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if(toastContainer.contains(toast)) {
                    toastContainer.removeChild(toast);
                }
            }, 300);
        }, 4000);
    }

    // ==========================================
    // Modal Management
    // ==========================================
    const overlay = document.getElementById('modal-overlay');
    let currentModal = null;

    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if(!modal) return;
        
        // Reset forms when opening
        const form = modal.querySelector('form');
        if(form) {
            form.reset();
            form.querySelectorAll('.form-group').forEach(g => g.classList.remove('invalid'));
        }

        modal.classList.remove('hidden');
        overlay.classList.remove('hidden');
        currentModal = modal;
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    }

    function closeModal() {
        if(currentModal) {
            currentModal.classList.add('hidden');
        }
        overlay.classList.add('hidden');
        document.body.style.overflow = '';
        currentModal = null;
    }

    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });

    overlay.addEventListener('click', closeModal);

    // ==========================================
    // Authentication Logic & DOM
    // ==========================================
    const authButtons = document.getElementById('auth-buttons');
    const userProfile = document.getElementById('user-profile');
    const userDropdown = document.getElementById('user-dropdown');
    const navUserName = document.getElementById('nav-user-name');
    
    const btnNavLogin = document.getElementById('btn-nav-login');
    const btnNavSignup = document.getElementById('btn-nav-signup');
    const btnNavLogout = document.getElementById('btn-nav-logout');
    const linkToSignup = document.getElementById('link-to-signup');
    const linkToLogin = document.getElementById('link-to-login');

    const formLogin = document.getElementById('form-login');
    const formSignup = document.getElementById('form-signup');

    function updateAuthState() {
        if (currentUser) {
            authButtons.classList.add('hidden');
            userProfile.classList.remove('hidden');
            navUserName.textContent = currentUser.name.split(' ')[0]; // Show first name
            
            // Show secure nav links
            document.getElementById('nav-history').classList.remove('hidden');
            document.getElementById('nav-manage').classList.remove('hidden');
        } else {
            authButtons.classList.remove('hidden');
            userProfile.classList.add('hidden');
            
            // Hide secure nav links
            document.getElementById('nav-history').classList.add('hidden');
            document.getElementById('nav-manage').classList.add('hidden');
            
            // If currently on a secure view, redirect
            if (!viewHistory.classList.contains('hidden') || !viewOrganizer.classList.contains('hidden')) {
                switchView('attendee');
            }
        }
    }

    updateAuthState(); // Initialize

    userProfile.addEventListener('click', (e) => {
        if(e.target.closest('#btn-nav-logout')) return;
        userDropdown.classList.toggle('hidden');
    });

    document.addEventListener('click', (e) => {
        if (!userProfile.contains(e.target)) {
            userDropdown.classList.add('hidden');
        }
    });

    btnNavLogin.addEventListener('click', () => openModal('modal-login'));
    btnNavSignup.addEventListener('click', () => openModal('modal-signup'));

    linkToSignup.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal();
        openModal('modal-signup');
    });

    linkToLogin.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal();
        openModal('modal-login');
    });

    // --- Sign Up (API) ---
    formSignup.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        let isValid = true;
        const inputs = Array.from(formSignup.querySelectorAll('input[required]'));
        inputs.forEach(input => {
            const group = input.closest('.form-group');
            if(!input.value.trim() || !input.checkValidity() || (input.type === 'password' && input.value.length < 6)) {
                group.classList.add('invalid');
                isValid = false;
            } else {
                group.classList.remove('invalid');
            }
        });

        if (!isValid) return;

        const name = document.getElementById('signup-name').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;

        try {
            const res = await fetch(`${API_BASE}/auth/signup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password })
            });

            const data = await res.json();

            if (!res.ok) {
                showToast('Registration Failed', data.error || 'Something went wrong.', 'error');
                return;
            }

            currentUser = data;
            saveCurrentUser();
            
            closeModal();
            updateAuthState();
            showToast('Welcome!', 'Your account has been created successfully.', 'success');
        } catch (err) {
            showToast('Network Error', 'Could not connect to the server.', 'error');
        }
    });

    // --- Log In (API) ---
    formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        let isValid = true;
        const inputs = Array.from(formLogin.querySelectorAll('input[required]'));
        inputs.forEach(input => {
            const group = input.closest('.form-group');
            if(!input.value.trim() || !input.checkValidity()) {
                group.classList.add('invalid');
                isValid = false;
            } else {
                group.classList.remove('invalid');
            }
        });

        if (!isValid) return;

        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        try {
            const res = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await res.json();

            if (!res.ok) {
                showToast('Login Failed', data.error || 'Invalid email or password.', 'error');
                return;
            }

            currentUser = data;
            saveCurrentUser();
            closeModal();
            updateAuthState();
            showToast('Welcome Back!', 'You have logged in successfully.', 'success');
        } catch (err) {
            showToast('Network Error', 'Could not connect to the server.', 'error');
        }
    });

    btnNavLogout.addEventListener('click', (e) => {
        e.preventDefault();
        currentUser = null;
        saveCurrentUser();
        userDropdown.classList.add('hidden');
        updateAuthState();
        switchView('attendee'); // Go back to browse
        showToast('Logged Out', 'You have been successfully logged out.', 'success');
    });

    // ==========================================
    // DOM Rendering - Attendee View (API)
    // ==========================================
    const eventsList = document.getElementById('events-list');
    const emptyStateAttendee = document.getElementById('empty-state-attendee');
    const searchInput = document.getElementById('search-events');

    function getCategoryIcon(category) {
        const map = {
            music: 'ph-music-notes', tech: 'ph-cpu', business: 'ph-briefcase',
            arts: 'ph-palette', sports: 'ph-barbell', other: 'ph-star'
        };
        return map[category] || 'ph-star';
    }

    async function renderAttendeeEvents(searchTerm = '') {
        eventsList.innerHTML = '';

        try {
            const url = searchTerm
                ? `${API_BASE}/events?search=${encodeURIComponent(searchTerm)}`
                : `${API_BASE}/events`;

            const res = await fetch(url);
            const events = await res.json();

            if (events.length === 0) {
                emptyStateAttendee.classList.remove('hidden');
                eventsList.style.display = 'none';
            } else {
                emptyStateAttendee.classList.add('hidden');
                eventsList.style.display = 'grid';

                events.forEach(event => {
                    const isSoldOut = event.sold >= event.capacity;
                    const priceDisplay = event.price === 0 ? '<span class="event-price free">FREE</span>' : `<span class="event-price">${formatCurrency(event.price)}</span>`;
                    
                    const card = document.createElement('div');
                    card.className = 'event-card glass';
                    card.innerHTML = `
                        <div class="event-card-img">
                            <i class="ph ${getCategoryIcon(event.category)}"></i>
                            <span class="event-category-badge">${event.category}</span>
                        </div>
                        <div class="event-card-content">
                            <div>
                                <h3 class="event-title">${event.name}</h3>
                                <div class="event-meta">
                                    <span><i class="ph ph-calendar"></i> ${formatDate(event.date)}</span>
                                    <span><i class="ph ph-map-pin"></i> ${event.location}</span>
                                </div>
                            </div>
                            <p style="font-size: 0.9rem; color: var(--clr-text-muted); line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${event.description}</p>
                            <div class="event-footer">
                                ${priceDisplay}
                                <button class="btn ${isSoldOut ? 'btn-secondary' : 'btn-primary btn-glow'}" 
                                    ${isSoldOut ? 'disabled' : ''}
                                    onclick="${isSoldOut ? '' : `window.openBookingModal('${event.id}')`}">
                                    ${isSoldOut ? 'Sold Out' : 'Book Ticket'}
                                </button>
                            </div>
                        </div>
                    `;
                    eventsList.appendChild(card);
                });
            }
        } catch (err) {
            showToast('Error', 'Could not load events from server.', 'error');
        }
    }

    // Debounce search to avoid flooding the API
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            renderAttendeeEvents(e.target.value);
        }, 300);
    });

    // ==========================================
    // DOM Rendering - History View (API)
    // ==========================================
    const historyList = document.getElementById('history-list');
    const emptyStateHistory = document.getElementById('empty-state-history');

    async function renderBookingHistory() {
        historyList.innerHTML = '';

        if (!currentUser) {
            emptyStateHistory.classList.remove('hidden');
            historyList.style.display = 'none';
            return;
        }

        try {
            const [bookingsRes, eventsRes] = await Promise.all([
                fetch(`${API_BASE}/bookings/${currentUser.id}`),
                fetch(`${API_BASE}/events`)
            ]);

            const bookings = await bookingsRes.json();
            const allEvents = await eventsRes.json();

            if (bookings.length === 0) {
                emptyStateHistory.classList.remove('hidden');
                historyList.style.display = 'none';
            } else {
                emptyStateHistory.classList.add('hidden');
                historyList.style.display = 'grid';

                bookings.forEach(booking => {
                    const event = allEvents.find(e => e.id === booking.event_id);
                    if (!event) return; // Event was deleted

                    const card = document.createElement('div');
                    card.className = 'event-card glass';
                    card.innerHTML = `
                        <div class="event-card-content">
                            <div>
                                <h3 class="event-title">${event.name}</h3>
                                <div class="event-meta">
                                    <span><i class="ph ph-calendar"></i> ${formatDate(event.date)}</span>
                                    <span><i class="ph ph-map-pin"></i> ${event.location}</span>
                                </div>
                            </div>
                            <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.05);">
                                <p style="font-size: 0.9rem; color: var(--clr-text-muted);">Name: ${booking.name}</p>
                                <p style="font-size: 0.9rem; color: var(--clr-text-muted);">Email: ${booking.email}</p>
                                <p style="font-size: 0.9rem; color: var(--clr-text-muted);">Booked On: ${formatDate(booking.booking_date)}</p>
                            </div>
                            <div class="event-footer">
                                <span style="font-size: 1.25rem; font-weight: 700; color: var(--clr-primary);">${booking.quantity} Ticket(s)</span>
                            </div>
                        </div>
                    `;
                    historyList.appendChild(card);
                });
            }
        } catch (err) {
            showToast('Error', 'Could not load booking history.', 'error');
        }
    }

    // ==========================================
    // Booking Logic (API)
    // ==========================================
    const formBookTicket = document.getElementById('form-book-ticket');
    const inputTicketQty = document.getElementById('ticket-quantity');
    const displayTotalPrice = document.getElementById('total-price-display');
    const inputBookEventPrice = document.getElementById('book-event-price-val');

    // Cache events data for booking modal
    let cachedEvents = [];

    // Make globally accessible for inline onclick
    window.openBookingModal = async function(eventId) {
        if (!currentUser) {
            openModal('modal-login');
            showToast('Authentication Required', 'Please log in to book a ticket.', 'warning');
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/events`);
            cachedEvents = await res.json();
        } catch (err) {
            showToast('Error', 'Could not load event details.', 'error');
            return;
        }

        const event = cachedEvents.find(e => e.id === eventId);
        if(!event) return;

        document.getElementById('book-event-id').value = event.id;
        document.getElementById('book-event-price-val').value = event.price;
        
        document.getElementById('book-event-title').textContent = event.name;
        document.getElementById('book-event-meta').innerHTML = `<i class="ph ph-calendar"></i> ${formatDate(event.date)} &bull; <i class="ph ph-map-pin"></i> ${event.location}`;
        
        // Auto-fill details
        document.getElementById('attendee-name').value = currentUser.name;
        document.getElementById('attendee-email').value = currentUser.email;

        // Reset totals view
        inputTicketQty.value = 1;
        inputTicketQty.max = Math.min(10, event.capacity - event.sold);
        updateTotalPrice();
        
        openModal('modal-book-ticket');
    };

    function updateTotalPrice() {
        const price = parseFloat(inputBookEventPrice.value) || 0;
        const qty = parseInt(inputTicketQty.value) || 1;
        displayTotalPrice.textContent = formatCurrency(price * qty);
    }

    inputTicketQty.addEventListener('input', updateTotalPrice);

    formBookTicket.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Basic Validation
        let isValid = true;
        const inputs = Array.from(formBookTicket.querySelectorAll('input[required]'));
        
        inputs.forEach(input => {
            const group = input.closest('.form-group');
            if(!input.value.trim() || !input.checkValidity()) {
                group.classList.add('invalid');
                isValid = false;
            } else {
                group.classList.remove('invalid');
            }
        });

        if(!isValid) return;

        // Process Booking via API
        const eventId = document.getElementById('book-event-id').value;
        const name = document.getElementById('attendee-name').value;
        const email = document.getElementById('attendee-email').value;
        const qty = parseInt(inputTicketQty.value);

        try {
            const res = await fetch(`${API_BASE}/bookings`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    eventId,
                    userId: currentUser.id,
                    name,
                    email,
                    quantity: qty
                })
            });

            const data = await res.json();

            if (!res.ok) {
                showToast('Booking Failed', data.error || 'Something went wrong.', 'error');
                return;
            }

            // Success flow
            closeModal();
            renderAttendeeEvents(searchInput.value);

            const event = cachedEvents.find(e => e.id === eventId);
            showToast('Booking Successful!', `You have booked ${qty} ticket(s) for ${event ? event.name : 'the event'}.`, 'success');
        } catch (err) {
            showToast('Network Error', 'Could not connect to the server.', 'error');
        }
    });

    // Remove invalid states on input
    document.querySelectorAll('input, select, textarea').forEach(el => {
        el.addEventListener('input', function() {
            const group = this.closest('.form-group');
            if(group) {
                if(this.checkValidity()) {
                    group.classList.remove('invalid');
                }
            }
        });
    });

    // ==========================================
    // DOM Rendering - Organizer View (API)
    // ==========================================
    const manageEventsTbody = document.getElementById('manage-events-tbody');
    const emptyStateOrganizer = document.getElementById('empty-state-organizer');

    async function renderOrganizerDashboard() {
        if (!currentUser) return;

        try {
            const res = await fetch(`${API_BASE}/events/organizer/${currentUser.id}`);
            const userEvents = await res.json();

            // Calculate Stats
            const totalEvents = userEvents.length;
            const totalCapacity = userEvents.reduce((sum, ev) => sum + ev.capacity, 0);
            const totalTicketsSold = userEvents.reduce((sum, ev) => sum + ev.sold, 0);

            // Update stats
            document.getElementById('stat-total-events').textContent = totalEvents;
            document.getElementById('stat-total-tickets').textContent = totalTicketsSold;
            document.getElementById('stat-total-capacity').textContent = totalCapacity;

            // Render Table
            manageEventsTbody.innerHTML = '';
            
            if (userEvents.length === 0) {
                emptyStateOrganizer.classList.remove('hidden');
                document.querySelector('.events-table').style.display = 'none';
            } else {
                emptyStateOrganizer.classList.add('hidden');
                document.querySelector('.events-table').style.display = 'table';

                userEvents.forEach(event => {
                    const tr = document.createElement('tr');
                    const isSoldOut = event.sold >= event.capacity;
                    const statusBadge = isSoldOut 
                        ? `<span class="status-badge status-soldout">Sold Out</span>`
                        : `<span class="status-badge status-active">Active</span>`;

                    tr.innerHTML = `
                        <td>
                            <strong>${event.name}</strong><br>
                            <span style="font-size:0.8rem;color:var(--clr-text-muted)">${event.category}</span>
                        </td>
                        <td>${formatDate(event.date)}</td>
                        <td>${event.location}</td>
                        <td>${event.sold} / ${event.capacity} <span style="font-size:0.8rem;color:var(--clr-text-muted)">(${Math.round((event.sold/event.capacity)*100)}%)</span></td>
                        <td>${statusBadge}</td>
                        <td>
                            <button class="btn-icon act-delete" onclick="window.deleteEvent('${event.id}')" title="Delete">
                                <i class="ph ph-trash"></i>
                            </button>
                        </td>
                    `;
                    manageEventsTbody.appendChild(tr);
                });
            }
        } catch (err) {
            showToast('Error', 'Could not load organizer dashboard.', 'error');
        }
    }

    // Modal triggers
    document.getElementById('btn-create-event').addEventListener('click', () => {
        openModal('modal-create-event');
    });

    // Create Event Form Handling (API)
    const formCreateEvent = document.getElementById('form-create-event');

    formCreateEvent.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        let isValid = true;
        const inputs = Array.from(formCreateEvent.querySelectorAll('input[required], select[required], textarea[required]'));
        
        inputs.forEach(input => {
            const group = input.closest('.form-group');
            if(!input.value.trim() || !input.checkValidity()) {
                group.classList.add('invalid');
                isValid = false;
            } else {
                group.classList.remove('invalid');
            }
        });

        // Additional date validation - must be future
        const dateInput = document.getElementById('event-date');
        if(dateInput.value) {
            const selectedDate = new Date(dateInput.value);
            if(selectedDate <= new Date()) {
                dateInput.closest('.form-group').classList.add('invalid');
                isValid = false;
                showToast('Validation Error', 'Event date must be in the future.', 'error');
            }
        }

        if(!isValid) return;

        // Create new event via API
        const newEvent = {
            organizerId: currentUser.id,
            name: document.getElementById('event-name').value,
            date: document.getElementById('event-date').value,
            location: document.getElementById('event-location').value,
            price: parseFloat(document.getElementById('event-price').value),
            capacity: parseInt(document.getElementById('event-capacity').value),
            category: document.getElementById('event-category').value,
            description: document.getElementById('event-desc').value
        };

        try {
            const res = await fetch(`${API_BASE}/events`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newEvent)
            });

            const data = await res.json();

            if (!res.ok) {
                showToast('Error', data.error || 'Could not create event.', 'error');
                return;
            }

            closeModal();
            renderOrganizerDashboard();
            showToast('Event Created', `${newEvent.name} has been successfully created and published!`, 'success');
        } catch (err) {
            showToast('Network Error', 'Could not connect to the server.', 'error');
        }
    });

    // Make globally accessible
    window.deleteEvent = async function(eventId) {
        if(confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
            try {
                const res = await fetch(`${API_BASE}/events/${eventId}`, {
                    method: 'DELETE'
                });

                if (!res.ok) {
                    const data = await res.json();
                    showToast('Error', data.error || 'Could not delete event.', 'error');
                    return;
                }

                renderOrganizerDashboard();
                showToast('Event Deleted', 'The event has been permanently removed.', 'success');
            } catch (err) {
                showToast('Network Error', 'Could not connect to the server.', 'error');
            }
        }
    };

    // ==========================================
    // Initialization
    // ==========================================
    // Set min date for datetime picker to today
    const now = new Date();
    // Format to YYYY-MM-DDThh:mm for datetime-local
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('event-date').min = now.toISOString().slice(0, 16);

    // Initial render — load events from API
    renderAttendeeEvents();
});
