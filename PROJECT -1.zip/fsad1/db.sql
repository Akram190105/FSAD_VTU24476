-- ============================================
-- EventVision Database Schema
-- ============================================
-- Run this file to create the database and tables:
--   mysql -u root -p < db.sql
-- ============================================

CREATE DATABASE IF NOT EXISTS eventify;
USE eventify;

-- ============================================
-- Users Table
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Events Table
-- ============================================
CREATE TABLE IF NOT EXISTS events (
    id VARCHAR(50) PRIMARY KEY,
    organizer_id VARCHAR(50) NULL,
    name VARCHAR(255) NOT NULL,
    date DATETIME NOT NULL,
    location VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    capacity INT NOT NULL DEFAULT 1,
    sold INT NOT NULL DEFAULT 0,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organizer_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================
-- Bookings Table
-- ============================================
CREATE TABLE IF NOT EXISTS bookings (
    id VARCHAR(50) PRIMARY KEY,
    event_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- Seed Data — Initial Events
-- ============================================
INSERT INTO events (id, organizer_id, name, date, location, price, capacity, sold, category, description) VALUES
('ev-1', NULL, 'Neon Nights Cyberpunk Festival', '2026-08-15 20:00:00', 'Downtown Neo-Tokyo', 150.00, 5000, 3450, 'music', 'Experience the future of music at this immersive cyberpunk themed multi-stage festival. Featuring top international DJs, holographic displays, and cutting edge tech.'),
('ev-2', NULL, 'Global Tech Summit 2026', '2026-09-10 09:00:00', 'Silicon Valley Convention Center', 0.00, 1000, 980, 'tech', 'Join industry leaders for a three-day summit discussing the latest advancements in AI, quantum computing, and sustainable tech infrastructure.'),
('ev-3', NULL, 'Modern Art Expo', '2026-07-22 10:00:00', 'Metropolitan Art Gallery', 25.50, 200, 45, 'arts', 'Explore breathtaking contemporary pieces from emerging artists around the globe in a curated immersive gallery experience.');
