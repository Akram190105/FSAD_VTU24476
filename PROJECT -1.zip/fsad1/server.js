/**
 * EventVision Backend Server
 * Node.js + Express + MySQL
 */

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// ============================================
// Middleware
// ============================================
app.use(cors());
app.use(express.json());

// Serve static frontend files
app.use(express.static(path.join(__dirname)));

// ============================================
// MySQL Database Connection
// ============================================
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',          // <-- Change this to your MySQL password
    database: 'eventify'
});

db.connect((err) => {
    if (err) {
        console.error('❌ MySQL Connection Error:', err.message);
        console.error('   Make sure MySQL is running and the "eventify" database exists.');
        console.error('   Run: mysql -u root -p < db.sql');
        return;
    }
    console.log('✅ Connected to MySQL database "eventify"');
});

// Helper: generate unique ID
function generateId() {
    return 'id-' + Math.random().toString(36).substr(2, 9);
}

// ============================================
// AUTH ROUTES
// ============================================

// POST /api/auth/signup — Register a new user
app.post('/api/auth/signup', (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    // Check if email already exists
    db.query('SELECT id FROM users WHERE email = ?', [email], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        if (results.length > 0) {
            return res.status(409).json({ error: 'An account with this email already exists.' });
        }

        const id = generateId();
        db.query(
            'INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)',
            [id, name, email, password],
            (err) => {
                if (err) return res.status(500).json({ error: err.message });
                res.status(201).json({ id, name, email });
            }
        );
    });
});

// POST /api/auth/login — Log in
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
    }

    db.query(
        'SELECT id, name, email FROM users WHERE email = ? AND password = ?',
        [email, password],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });

            if (results.length === 0) {
                return res.status(401).json({ error: 'Invalid email or password.' });
            }

            res.json(results[0]);
        }
    );
});

// ============================================
// EVENT ROUTES
// ============================================

// GET /api/events — Get all events (with optional search)
app.get('/api/events', (req, res) => {
    const search = req.query.search || '';

    let query = 'SELECT * FROM events';
    let params = [];

    if (search) {
        query += ' WHERE name LIKE ? OR location LIKE ? OR category LIKE ?';
        const term = `%${search}%`;
        params = [term, term, term];
    }

    query += ' ORDER BY created_at DESC';

    db.query(query, params, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// POST /api/events — Create a new event
app.post('/api/events', (req, res) => {
    const { organizerId, name, date, location, price, capacity, category, description } = req.body;

    if (!name || !date || !location || price === undefined || !capacity || !category || !description) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    const id = generateId();
    db.query(
        `INSERT INTO events (id, organizer_id, name, date, location, price, capacity, sold, category, description)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
        [id, organizerId, name, date, location, price, capacity, category, description],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ id, organizerId, name, date, location, price, capacity, sold: 0, category, description });
        }
    );
});

// DELETE /api/events/:id — Delete an event and its bookings
app.delete('/api/events/:id', (req, res) => {
    const eventId = req.params.id;

    // Bookings are deleted by CASCADE
    db.query('DELETE FROM events WHERE id = ?', [eventId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Event not found.' });
        }

        res.json({ message: 'Event deleted successfully.' });
    });
});

// GET /api/events/organizer/:userId — Get events by organizer
app.get('/api/events/organizer/:userId', (req, res) => {
    db.query(
        'SELECT * FROM events WHERE organizer_id = ? ORDER BY created_at DESC',
        [req.params.userId],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        }
    );
});

// ============================================
// BOOKING ROUTES
// ============================================

// GET /api/bookings/:userId — Get bookings for a user
app.get('/api/bookings/:userId', (req, res) => {
    db.query(
        'SELECT * FROM bookings WHERE user_id = ? ORDER BY booking_date DESC',
        [req.params.userId],
        (err, results) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(results);
        }
    );
});

// POST /api/bookings — Create a new booking
app.post('/api/bookings', (req, res) => {
    const { eventId, userId, name, email, quantity } = req.body;

    if (!eventId || !userId || !name || !email || !quantity) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    // Check capacity first
    db.query('SELECT capacity, sold FROM events WHERE id = ?', [eventId], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        if (results.length === 0) {
            return res.status(404).json({ error: 'Event not found.' });
        }

        const event = results[0];
        if (event.sold + quantity > event.capacity) {
            return res.status(400).json({ error: 'Not enough tickets available.' });
        }

        const id = generateId();

        // Insert booking
        db.query(
            'INSERT INTO bookings (id, event_id, user_id, name, email, quantity) VALUES (?, ?, ?, ?, ?, ?)',
            [id, eventId, userId, name, email, quantity],
            (err) => {
                if (err) return res.status(500).json({ error: err.message });

                // Update sold count
                db.query(
                    'UPDATE events SET sold = sold + ? WHERE id = ?',
                    [quantity, eventId],
                    (err) => {
                        if (err) return res.status(500).json({ error: err.message });
                        res.status(201).json({ id, eventId, userId, name, email, quantity, bookingDate: new Date().toISOString() });
                    }
                );
            }
        );
    });
});

// ============================================
// Start Server
// ============================================
app.listen(PORT, () => {
    console.log(`🚀 EventVision server running at http://localhost:${PORT}`);
});
